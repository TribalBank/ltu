Development moved to https://gitlab.com/blacknet-ninja

https://lawfultenderunit.org/ aims to continue on LAWFULTENDERUNIT chain.
